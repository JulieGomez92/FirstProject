//Before any of our JS can function, it should be in a "device ready" function that Cordova detected all foundational elements have been loaded
//Listen for the moment alal your filed load into memory 
//Then run the main function "onDeviceReady()"



document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady () {

//All future JS code MUST be in the onDeviceReady main function!
  console.log("Cordova is ready!?");
}//END onDeviceReady()

// ---- Variables ----
//Containers for data 
/* Create Variables for the Sign Up/Log In forms. and the log out Button */
// var - classic way - still works
// let - newer way: reccomend way to create an Object that varies 
//const - newest way: reccomended way to coreate an object that does not vary
//document.getElementByID ("fmSignUp") - means find an HTML Element with that ID - pJS
//$("#fmSignUp") - means find an HTML Element wiht that ID 

const $elFmSignUp =$("#fmSignUp"),
//$ = search and fm = ID and #= ID 
      $elFmLogIn =$("#fmLogIn"),
      $elBtnLogOut =$("#btnLogOut");

 //Create variables to read the <input> of this form <form>
 //let $elInEmailSignUp =$("#inEmailSignUp"),
      //$elInPasswordSignUp = $("#inPasswordSignUp"),
      //$elInPasswordConfirmSignUp =$("#inPasswordConfirmSignup");

      //quick test to read what's in the box 

//---Event Listeners ---

$elFmSignUp.submit(function(){fnSignUp(event);});
$elFmLogIn.submit(function(){fnLogIn(event);});
$elBtnLogOut.on("click", fnLogOut);


// ---- Functions ---- 
// Create a function to do all the steps signing up for an account  
function fnSignUp(event){  
  //Prevent the defaul event of refreshing the screen 
  //fm = form
  //fn = function
  //fnSignUp was invented by user 

 event.preventDefault();
 console.log("fnSignUp(event)is running");
 let $elInEmailSignUp =$("#inEmailSignUp"),
 $elInPasswordSignUp = $("#inPasswordSignUp"),
 $elInPasswordConfirmSignUp = $("#inPasswordConfirmSignUp");



//$elFmSignUp.submit(function(){fnSignUp(event);});
//$elFmLogIn.submit(function(){fnLogIn(event);});
//$elBtnLogOut.on("click", "fnLogOut");


//Check if the Password and Confirm Password match via conditional statements 
if($elInPasswordSignUp.val() !=$elInPasswordConfirmSignUp.val()) {
        //Deal with passwords not matching
        console.log("PwDs DON'T match!");
        //Let the user know, via popup
        window.alert ("Passwords don't match");
      } else {
        //Deal with passwords that DO MATCH 
      conosle.log("PwDs DO match!");
      //Use localStorage to save the user data, as a new account 
      //localStorage.setItem("memorylocation", "data");
      //localStorage.setItem("user1", jgomez@my.fsu.edu/BeckettDog");
      //localStorage.setItem("vcampos@sdccd.edu", "Beckettboy");
      //Capitalization matter so try to simplify when possible 
      let $tmpValInEmailSignUp = $elInEmailSignUp.val().toUpperCase()
      $tmpValInPasswordSignUp = $elInPasswordSignUp.val();

      //Before saving to the localStorage, check if they've been saved before 
      if(localStorage.getItem($tmpValInEmailSignUp)===null) {
        console.log("New User detected");

// So, store the new user 
        localStorage.setItem($tmpValInEmailSignUp, $tmpValInPasswordSignUp);
        //Then clear the form for the next user
          $elFmSignUp[0].reset();
        window.alert("Welcome to CBDB!");
        console.log("New user saved:"+$tmpValInEmailSignUp);
      }else {
        console.log("Previous User detected");
        wndow.alart("You already have an account");
        
      } //END if..  Else for new/old user checking
      } //END if.. Else password confirm checker 

if ($tmpValInPasswordLogIn === localStorage.getItem($tmpEmailLogIn)) {
  console.log("Passwords DO match.");
  $(":mobile-pagecontainer").pagecontainer("change", "pgHome");
}else{
  window.alert("Wrong password!");
}//END If..Else checking for User account existence 

} //END fnSIgnUp(event) 

//The subroutines (buncldes of code) that accomplish a task 

function fnLogOut (){
  console.log("fnLogOut() is running");
  switch(window.confirm("Do you want to log out?")) {
    case true:
    $elFmSignUp[0].reset(); $elFmLogIn[0].reset();
    $(":mobile-pagecontainer").pagecontainer("change","#pgWelcome");
    break;
    case false:
    console.log("Use DOES NOT want to log out");
    break;
    deafult:
    console.log("Unknown error");
    break;
  }//END switch () to log out 
}